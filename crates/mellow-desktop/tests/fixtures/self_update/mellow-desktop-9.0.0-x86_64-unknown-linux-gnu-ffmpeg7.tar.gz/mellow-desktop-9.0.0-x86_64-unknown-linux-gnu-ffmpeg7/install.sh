#!/bin/sh
# Test stand-in for packaging/linux/install.sh: installs bin/mellow the same way.
set -eu
package_directory=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
mkdir -p "${HOME}/.local/bin"
cp -- "${package_directory}/bin/mellow" "${HOME}/.local/bin/.mellow.new"
chmod 755 "${HOME}/.local/bin/.mellow.new"
mv -f -- "${HOME}/.local/bin/.mellow.new" "${HOME}/.local/bin/mellow"
